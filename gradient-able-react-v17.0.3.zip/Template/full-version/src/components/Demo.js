import React from 'react';

const  = ({ params }) => {
    return (

    );
};

export default ;
